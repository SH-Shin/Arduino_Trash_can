

/*****************************************************************************/
/*GPIO MACRO*/
/*****************************************************************************/
#define SENSOR_TR 6
#define SENSOR_EC 7


/*****************************************************************************/
/*Declare Funtions*/
/*****************************************************************************/
void HC_SR04_Init();
float Read_Distance();
int Distance_Event();


/*****************************************************************************/
/*HC_SR04_Init*/
/*****************************************************************************/
void HC_SR04_Init()
{
  	pinMode(SENSOR_TR, OUTPUT);
  	pinMode(SENSOR_EC, INPUT);
}

/*****************************************************************************/
/*Reading Distance*/
/*****************************************************************************/
float Read_Distance()
{
  	digitalWrite(SENSOR_TR, LOW);
  	delayMicroseconds(2);
  	digitalWrite(SENSOR_TR, HIGH);
  	delayMicroseconds(10);
  	digitalWrite(SENSOR_TR, LOW);
  
  	float fDistance = pulseIn(SENSOR_EC, HIGH) / 29.0 / 2.0;  
//      Serial.println(fDistance);  // for test

    return fDistance;
}

/*****************************************************************************/
/*Distance_Event*/
/*****************************************************************************/
int Distance_Event()
{
    float fTemp = Read_Distance();

    
    if (fTemp >= 10)   
    {
        return 180;
    }
    else
    {
        return 0;
    }
}

